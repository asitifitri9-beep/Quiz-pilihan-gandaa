const questions = [
    {
        question: "Ibukota Indonesia adalah?",
        choices: ["Bandung", "Jakarta", "Surabaya", "Medan"],
        answer: "Jakarta"
    },
    {
        question: "Gunung tertinggi di Indonesia adalah?",
        choices: ["Gunung Rinjani", "Gunung Semeru", "Puncak Jaya", "Gunung Merbabu"],
        answer: "Puncak Jaya"
    },
    {
        question: "Lambang negara Indonesia adalah?",
        choices: ["Garuda Pancasila", "Merpati Putih", "Elang Jawa", "Bendera Merah Putih"],
        answer: "Garuda Pancasila"
    }
];

let currentQuestionIndex = 0;
let score = 0;
let timer;
const timePerQuestion = 10;

const questionEl = document.getElementById("question");
const choicesEl = document.getElementById("choices");
const resultEl = document.getElementById("result");
const scoreEl = document.getElementById("score");
const restartBtn = document.getElementById("restart-btn");
const timeLeftEl = document.getElementById("time-left");
const progressBarEl = document.getElementById("progress-bar");

function startTimer() {
    let time = timePerQuestion;
    timeLeftEl.textContent = time;
    progressBarEl.style.width = "100%";
    progressBarEl.style.backgroundColor = "#28a745";

    timer = setInterval(() => {
        time--;
        timeLeftEl.textContent = time;

        let progressWidth = (time / timePerQuestion) * 100;
        progressBarEl.style.width = progressWidth + "%";

        if (time <= 3) progressBarEl.style.backgroundColor = "#dc3545"; 
        else if (time <= 6) progressBarEl.style.backgroundColor = "#ffc107";

        if (time <= 0) {
            clearInterval(timer);
            alert("Waktu habis!");
            nextQuestion();
        }
    }, 1000);
}

function showQuestion() {
    clearInterval(timer);
    const currentQuestion = questions[currentQuestionIndex];
    questionEl.textContent = currentQuestion.question;
    choicesEl.innerHTML = "";
    currentQuestion.choices.forEach(choice => {
        const btn = document.createElement("button");
        btn.textContent = choice;
        btn.classList.add("choice");
        btn.addEventListener("click", () => selectAnswer(choice));
        choicesEl.appendChild(btn);
    });
    startTimer();
}

function selectAnswer(choice) {
    clearInterval(timer);
    const correct = questions[currentQuestionIndex].answer;
    if (choice === correct) {
        score++;
        alert("Benar!");
    } else {
        alert(`Salah! Jawaban benar: ${correct}`);
    }
    nextQuestion();
}

function nextQuestion() {
    currentQuestionIndex++;
    if (currentQuestionIndex < questions.length) {
        showQuestion();
    } else {
        endQuiz();
    }
}

function endQuiz() {
    clearInterval(timer);
    document.getElementById("quiz").classList.add("hidden");
    resultEl.classList.remove("hidden");
    scoreEl.textContent = `${score} / ${questions.length}`;
}

restartBtn.addEventListener("click", () => {
    currentQuestionIndex = 0;
    score = 0;
    resultEl.classList.add("hidden");
    document.getElementById("quiz").classList.remove("hidden");
    showQuestion();
});

showQuestion();